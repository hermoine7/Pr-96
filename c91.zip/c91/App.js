import * as React from 'react';
import { Text, View, StyleSheet } from 'react-native';
import { createAppContainer, createSwitchNavigator,} from 'react-navigation';
import { createBottomTabNavigator } from 'react-navigation-tabs';

import WS from './Screens/WelcomeScreen';
import SS from './Screens/SignUp';
import LS from './Screens/Login';
import NS from './Screens/NewScreen';
import AS from './Screens/AvailScreen';
import PD from './Screens/PassDetails';

export default function App() {
  //#37c2ed #ffd800
  return (
    <AppContainer/>
  );
}

const TabNavigator = createBottomTabNavigator({
  AvailableJobs : {
    screen: AS,
    navigationOptions :{
      tabBarLabel : "Passwords",
    }
  },
  NewJob: {
    screen: NS,
    navigationOptions :{
      tabBarLabel : "New passwords",
    }
  }
})

const switchNavigator = createSwitchNavigator({
  WelcomeScreen:{screen: WS},
  LoginScreen:{screen: LS},
  SS: {screen: SS},
  TabNav: TabNavigator,
  PassDetails: {screen: PD}
  
  })

const AppContainer = createAppContainer(switchNavigator);
