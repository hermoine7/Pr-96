import React, { Component} from 'react';
import { Header} from 'react-native-elements';
import { View, Text, StyeSheet ,Alert} from 'react-native';

export default class MyHeader extends Component{

  render(){
    return(
      <Header
        centerComponent={{ text: this.props.title, style: { color: 'black', fontSize:30, fontFamily:'x' } }}
        backgroundColor = "#CD9648"
        />
    )
  }

}