import React from 'react';
import { Text, View,Image,TextInput,TouchableOpacity,StyleSheet, Dimensions, FlatList } from 'react-native';
import MyHeader from '../MyHeader'
import { ListItem } from 'react-native-elements'
import firebase from 'firebase'
import db from '../config'
import {SearchBar} from 'react-native-elements';

export default class AJ extends React.Component{
    constructor(){
    super();
    this.state ={
      avaiablePasswords : [],
      dataSource:[],
      search : ''
    }
    this.requestRef= null
  }

  getAvaiablePasswords =()=>{
    this.requestRef = db.collection("Jobs")
    .onSnapshot((snapshot)=>{
      var avaiablePasswords = snapshot.docs.map((doc) => doc.data())
      this.setState({
        avaiablePasswords : avaiablePasswords
      });
    })
  }

  componentDidMount(){
    this.getAvaiablePasswords()
  }

  componentWillUnmount(){
    this.requestRef();
  }

  keyExtractor = (item, index) => index.toString()

  renderItem = ( {item, i} ) =>{
    return (
      <ListItem
        key={i}
        title={item.appName}
        subtitle={item.username}
        titleStyle={{ color: 'black', fontWeight: 'bold' }}
        rightElement={
            <TouchableOpacity style={styles.button}
              onPress ={()=>{
                this.props.navigation.navigate("RecieverDetails", {"details": item})
              }}
              >
              <Text style={{color:'#ffff'}}>View</Text>
            </TouchableOpacity>
          }
        bottomDivider
      />
    )
  }

  SearchFilterFunction(text) {
    const newData = this.state.avaiablePasswords.filter((item)=> {
     
      const itemData = item.appName ? item.appName.toUpperCase() : ''.toUpperCase();
      const textData = text.toUpperCase();
      return itemData.indexOf(textData) > -1;
    });
    this.setState({
      dataSource: newData,
      search: text,
    });
  }


    render(){
    return(
        <View style={{backgroundColor:'#ada29c',height: Dimensions.get('window').height }}>
           <MyHeader title=" Passwords" style={{height:50}}/>
           <TouchableOpacity onPress = {()=>{this.props.navigation.navigate('WelcomeScreen')}}>
        <Image style={{height:50,width:50, marginTop:-45}} source={require('../assets/Back.png')}/>
        </TouchableOpacity>

         <SearchBar
              placeholder="Type Here..."
              onChangeText={text => this.SearchFilterFunction(text)}
              onClear={text => this.SearchFilterFunction('')}
              value={this.state.search}
            />

           <View style={{flex:1}}>
          {
            this.state.avaiablePasswords.length === 0
            ?(
              <View style={styles.subContainer}>
                <Text style={{ fontSize: 20}}>List Of All Available Passwords</Text>
              </View>
            )
            :(
              <FlatList
                data={this.state.search === "" ?  this.state.avaiablePasswords: this.state.dataSource}
                renderItem={({ item }) => (
                  <View style={styles.itemContainer}>
                    <Text>  App name: {item.appName}</Text>
                    <Text>  Username : {item.username}</Text>
            <TouchableOpacity style={styles.button}
              onPress ={()=>{
                this.props.navigation.navigate("PassDetails", {"details": item})
              }}
              >
              <Text style={{color:'#ffff'}}>View</Text>
            </TouchableOpacity>
                  </View>
                )}
                keyExtractor={(item, index) => index.toString()}
                /> 
            )
          }
        </View>
        </View>
    )
        
}
}

const styles = StyleSheet.create({
  subContainer:{
    flex:1,
    fontSize: 20,
    justifyContent:'center',
    alignItems:'center'
  },
  button:{
    width:100,
    height:30,
    justifyContent:'center',
    alignItems:'center',
    backgroundColor:"#CD9648",
    shadowColor: "#000",
    shadowOpacity: 0.44,
    shadowRadius: 10.32,
    shadowOffset: {
       width: 0,
       height: 8
     },
     alignSelf:'center',
     marginRight:15,
  },
  itemContainer: {
    width:'98%',
    borderWidth: 2,
    borderColor: 'black',
    justifyContent:'center',
    alignSelf: 'center',
    borderRadius:10,
    backgroundColor:'white',
    marginTop:10
  }
})

