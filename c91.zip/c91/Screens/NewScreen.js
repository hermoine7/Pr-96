import React from 'react';
import { Text, View,Image, Dimensions, TouchableOpacity, StyleSheet, TextInput, KeyboardAvoidingView } from 'react-native';
import MyHeader from '../MyHeader'
import db from '../config'

export default class SDG1Screen extends React.Component{
  constructor(){
    super();
    this.state ={
      appName:'',
      username:'',
      password: '',
      requestId:''
    }
  }
  createUniqueId(){
    return Math.random().toString(36).substring(7);
  }

  addRequest = async (appName, username, password)=>{
    if(this.state.appName, this.state.username, this.state.password){
    var randomRequestId = this.createUniqueId()
    db.collection('Jobs').add({
        "appName": this.state.appName,
        "username":this.state.username,
        "password":this.state.password,
    })
    this.setState({
      appName:'',
      username:'',
      password:'',
      requestId: randomRequestId
    })

    alert(" Job Successfully Posted")

    }
    else {
      alert('Please fill out all forms')
    }
  }
    render(){
    return(
        <View style={{backgroundColor:'#ada29c', height: Dimensions.get('window').height}}>
        <MyHeader title="New Password"/>
        <TouchableOpacity onPress = {()=>{this.props.navigation.navigate('WelcomeScreen')}}>
        <Image style={{height:50,width:50, marginTop:-45}} source={require('../assets/Back.png')}/>
        </TouchableOpacity>
         <TextInput
          style={styles.inputBox}
          placeholder ={"app Name"}
          onChangeText={text => {
            this.setState({ appName: text });
          }}
          value={this.state.appName}
        />
        <TextInput
          style={styles.inputBox}
          placeholder ={"app username"}
          onChangeText={text => {
            this.setState({ username: text });
          }}
          value={this.state.username}
        />
        <TextInput
          style={styles.inputBox}
          placeholder ={"app Password"}
          onChangeText={text => {
            this.setState({ password: text });
          }}
          value={this.state.password}
        />

        <TouchableOpacity 
        style={styles.button}
        onPress={()=>{this.addRequest(this.state.appName,this.state.username, this.state.password)}}
        >
     <Text style={styles.buttonText} >Submit</Text>
     </TouchableOpacity>
    
        </View>
    )
}
}

const styles = StyleSheet.create({
  button: {
    marginTop:20,
    backgroundColor:'#CD9648',
    height:40,
    width:200,
    alignSelf:'center',
    borderWidth:2,
    alignItems:'center',
    justifyContent:'center',
    borderRadius:10,
  }, 
  buttonText:{
    fontWeight:'bold',
    color:'black',
    fontSize:20
  },
  inputBox:{
    width:200,
    color:"black",
    borderWidth:2,
    height:40,
    alignItems:'center',
    alignSelf:'center',
    borderRadius:10,
    marginTop:10,
  },
});
