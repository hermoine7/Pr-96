import React ,{Component} from 'react';
import {View,Text,StyleSheet,TouchableOpacity, Dimensions,Image} from 'react-native';
import{Card,Header,Icon} from 'react-native-elements';

import db from '../config'

export default class RecieverDetailsScreen extends Component{
  constructor(props){
    super(props);
    this.state={
      appName        : this.props.navigation.getParam('details')["appName"],
      username     : this.props.navigation.getParam('details')["username"],
      password: this.props.navigation.getParam('details')["password"],
      requestId       : this.props.navigation.getParam('details')["request_id"],
    }
  }

  getRecieverDetails=()=>{
    db.collection('Jobs').where('request_id','==',this.state.requestId).get()
    .then(snapshot=>{
      snapshot.forEach(doc => {
        var avaiableJobs = snapshot.docs.map((doc) => doc.data())
     })
  })}

  buttonPress=()=>{
    alert('email  your resume to '+this.state.email)
  }
  render(){
      return(
        <View style={{backgroundColor:'#ada29c', height:Dimensions.get('window').height}}>
          <View >
        <TouchableOpacity onPress = {()=>{this.props.navigation.navigate('TabNav')}}>
        <Image style={{height:50,width:50}} source={require('../assets/Back.png')}/>
        </TouchableOpacity>
            <Card
                title={"App Information"}
                titleStyle= {{fontSize : 20, backgroundColor:'#CD9648'}}
              >
              <Card >
                <Text style={{fontWeight:'bold'}}>App Name : {this.state.appName}</Text>
                <Text style={{fontWeight:'bold'}}>Username : {this.state.username}</Text>
                <Text style={{fontWeight:'bold'}}>Password : {this.state.password}</Text>
              </Card>
            </Card>

          </View>
        </View>
      )
    }

}


const styles = StyleSheet.create({
  buttonContainer : {
    flex:0.3,
    justifyContent:'center',
    alignItems:'center'
  },
  button:{
    width:"75%",
    height:50,
    justifyContent:'center',
    alignItems:'center',
    borderRadius:10,
    backgroundColor:"#c9a2b7",
    shadowColor: "#000",
    shadowOffset: {
       width: 0,
       height: 8,
    },
    shadowOpacity: 0.44,
    shadowRadius: 10.32,
    elevation: 16,
    marginTop:20
    },
})