import React from 'react';
import { Text, View,Image, Dimensions, TouchableOpacity, StyleSheet, TextInput, KeyboardAvoidingView } from 'react-native';
import MyHeader from '../MyHeader'


export default class SDG1Screen extends React.Component{
    constructor() {
    super();
    this.state = {
      name:'',
      sq1:'',
      sq2:''
    };
     }
    render(){
    return(
        <View style={{backgroundColor:'#ada29c'}}>
        <MyHeader title="Sign Up"/>
        <TouchableOpacity onPress = {()=>{this.props.navigation.navigate('WelcomeScreen')}}>
        <Image style={{height:50,width:50, marginTop:-45}} source={require('../assets/Back.png')}/>
        </TouchableOpacity>
     <KeyboardAvoidingView style={{alignItems:'center',  height: Dimensions.get('window').height-45}}>
      <TextInput
          style={styles.inputBox}
          placeholder ={"Name"}
          onChangeText={text => {
            this.setState({ name: text });
          }}
          value={this.state.name}
        />
        <Text style={{fontSize:30, fontFamily:'x', textDecorationLine:'underline',marginTop:20, alignSelf:'flex-start', marginLeft:10}}>Security Questions-</Text>
        <Text style={{fontSize:20, fontFamily:'x', marginTop:10, alignSelf:'flex-start', marginLeft:10}}>1.Where were you born?</Text>
        <TextInput
          style={styles.inputBox2}
          onChangeText={text => {
            this.setState({ sq1: text });
          }}
          value={this.state.sq1}
        />
         <Text style={{fontSize:20, fontFamily:'x', marginTop:10, alignSelf:'flex-start', marginLeft:10}}>2.What was the name of the first school you studied in?</Text>
        <TextInput
          style={styles.inputBox2}
          onChangeText={text => {
            this.setState({ sq2: text });
          }}
          value={this.state.sq2}
        />
        <TouchableOpacity style={styles.button}>
     <Text style={styles.buttonText} onPress={()=>this.props.navigation.navigate('TabNav')}>Submit</Text>
     </TouchableOpacity>

     </KeyboardAvoidingView>
        </View>
    )
        
}
}
const styles = StyleSheet.create({
  button: {
    marginTop:20,
    backgroundColor:'#CD9648',
    height:40,
    width:200,
    alignSelf:'center',
    borderWidth:2,
    alignItems:'center',
    justifyContent:'center',
    borderRadius:10,
  },
  buttonText:{
    fontWeight:'bold',
    color:'black',
    fontSize:20
  },
  inputBox:{
    width:250,
    color:"black",
    borderWidth:2,
    height:40,
    alignItems:'center',
    alignSelf:'center',
    borderRadius:10,
    marginTop:30,
  },
  inputBox2:{
    width:300,
    color:"black",
    borderWidth:2,
    height:40,
    alignItems:'center',
    alignSelf:'center',
    borderRadius:10,
    marginTop:10,
  },
});