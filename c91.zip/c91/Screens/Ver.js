import React from 'react';
import { Text, View,Image, Dimensions, TouchableOpacity, StyleSheet, TextInput, KeyboardAvoidingView } from 'react-native';
import {
GoogleSignin,
GoogleSigninButton,
statusCodes,
} from 'react-native-google-signin';

export default class SDG1Screen extends React.Component{
    constructor() {
    super();
    this.state = {
      password:''
    };
     }
    render(){
    return(
        <View style={{backgroundColor:'#ada29c', height: Dimensions.get('window').height, alignItems:'center', justifyContent:'center'}}>
            <Text style={{fontSize:40, fontFamily:'x', textDecorationLine:'underline'}}>Welcome </Text>
            <Image style={{height:250, width:250}} source={require('../assets/Logo.png')} />
        </View>
    )
        
}
}
const styles = StyleSheet.create({
  button: {
    marginTop:20,
    backgroundColor:'#CD9648',
    height:40,
    width:200,
    alignSelf:'center',
    borderWidth:2,
    alignItems:'center',
    justifyContent:'center',
    borderRadius:10,
  }, 
  buttonText:{
    fontWeight:'bold',
    color:'black',
    fontSize:20
  }
});