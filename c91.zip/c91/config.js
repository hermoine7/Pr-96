import firebase, {firestore} from 'firebase'
var firebaseConfig = {
    apiKey: "AIzaSyDWTxXmlgbllKtQELhXYyVxD6b4SNnC0yc",
    authDomain: "magic-passwords.firebaseapp.com",
    projectId: "magic-passwords",
    storageBucket: "magic-passwords.appspot.com",
    messagingSenderId: "191154654967",
    appId: "1:191154654967:web:e6d2727c7fe64b54358df2"
  };
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);
  export default firebase.firestore();